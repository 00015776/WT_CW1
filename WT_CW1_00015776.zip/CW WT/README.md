First I choose a one local company which is UZBEKNEFTEGAZ
Then I started to built a project as similar as possible
To create a this project helped me a Visual Studio Code
In that app was used a tools such as HTML, CSS and JS
HTML helped to put text, images, lines, animations and others
CSS helped to style them and designs them with colors, orders, functions and others 
 JS helped to control functions in the HTML
After finishing hall project I run my project to Github pages and got a link